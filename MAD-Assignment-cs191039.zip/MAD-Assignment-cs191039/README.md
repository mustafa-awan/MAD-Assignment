# MAD-Assignment
 
